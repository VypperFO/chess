var class_chess_game_1_1model_1_1_player =
[
    [ "Player", "class_chess_game_1_1model_1_1_player.html#aa040913e142aef33217aa056749eb418", null ],
    [ "Player", "class_chess_game_1_1model_1_1_player.html#ac051fcabc8729e343e2f2d58166774f6", null ],
    [ "Name", "class_chess_game_1_1model_1_1_player.html#af61f864c782b49d6a078345db47a9ff4", null ],
    [ "NbDefeat", "class_chess_game_1_1model_1_1_player.html#a49c9b9eabb6998d64686bdab2c2a17e7", null ],
    [ "NbNull", "class_chess_game_1_1model_1_1_player.html#a47c224a5e200de23c08e85a03c367734", null ],
    [ "NbVictory", "class_chess_game_1_1model_1_1_player.html#afed1b479d95e4015b252cfd8c43a1458", null ]
];