var _board_8cs =
[
    [ "ChessGame.model.Board", "class_chess_game_1_1model_1_1_board.html", "class_chess_game_1_1model_1_1_board" ]
];