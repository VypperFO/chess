var dir_4c35fb7f3abf581bd7f272b4592ef4fc =
[
    [ "pieces", "dir_0707acc1238df4c6c2268f5b96e1c857.html", "dir_0707acc1238df4c6c2268f5b96e1c857" ],
    [ "Board.cs", "_board_8cs.html", "_board_8cs" ],
    [ "Coordinates.cs", "_coordinates_8cs.html", "_coordinates_8cs" ],
    [ "Game.cs", "_game_8cs.html", "_game_8cs" ],
    [ "Player.cs", "_player_8cs.html", "_player_8cs" ]
];