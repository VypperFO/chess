var namespace_chess_game =
[
    [ "model", "namespace_chess_game_1_1model.html", "namespace_chess_game_1_1model" ],
    [ "Properties", "namespace_chess_game_1_1_properties.html", "namespace_chess_game_1_1_properties" ],
    [ "view", "namespace_chess_game_1_1view.html", "namespace_chess_game_1_1view" ],
    [ "Chess", "class_chess_game_1_1_chess.html", "class_chess_game_1_1_chess" ]
];