var hierarchy =
[
    [ "ChessGame.model.Board", "class_chess_game_1_1model_1_1_board.html", null ],
    [ "ChessGame.Chess", "class_chess_game_1_1_chess.html", null ],
    [ "ChessGame.model.Coordinates", "class_chess_game_1_1model_1_1_coordinates.html", null ],
    [ "Form", null, [
      [ "ChessGame.view.FormGame", "class_chess_game_1_1view_1_1_form_game.html", null ],
      [ "ChessGame.view.FormMenu", "class_chess_game_1_1view_1_1_form_menu.html", null ]
    ] ],
    [ "ChessGame.model.Game", "class_chess_game_1_1model_1_1_game.html", null ],
    [ "ChessGame.model.pieces.Piece", "class_chess_game_1_1model_1_1pieces_1_1_piece.html", [
      [ "ChessGame.model.pieces.Bishop", "class_chess_game_1_1model_1_1pieces_1_1_bishop.html", null ],
      [ "ChessGame.model.pieces.Knight", "class_chess_game_1_1model_1_1pieces_1_1_knight.html", null ],
      [ "ChessGame.model.pieces.Queen", "class_chess_game_1_1model_1_1pieces_1_1_queen.html", null ],
      [ "ChessGame.model.pieces.SpecialPiece", "class_chess_game_1_1model_1_1pieces_1_1_special_piece.html", [
        [ "ChessGame.model.pieces.King", "class_chess_game_1_1model_1_1pieces_1_1_king.html", null ],
        [ "ChessGame.model.pieces.Pawn", "class_chess_game_1_1model_1_1pieces_1_1_pawn.html", null ],
        [ "ChessGame.model.pieces.Rook", "class_chess_game_1_1model_1_1pieces_1_1_rook.html", null ]
      ] ]
    ] ],
    [ "ChessGame.model.Player", "class_chess_game_1_1model_1_1_player.html", null ],
    [ "ChessGame.Properties.Resources", "class_chess_game_1_1_properties_1_1_resources.html", null ]
];