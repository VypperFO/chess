var annotated_dup =
[
    [ "ChessGame", "namespace_chess_game.html", [
      [ "model", "namespace_chess_game_1_1model.html", [
        [ "pieces", "namespace_chess_game_1_1model_1_1pieces.html", [
          [ "Bishop", "class_chess_game_1_1model_1_1pieces_1_1_bishop.html", "class_chess_game_1_1model_1_1pieces_1_1_bishop" ],
          [ "King", "class_chess_game_1_1model_1_1pieces_1_1_king.html", "class_chess_game_1_1model_1_1pieces_1_1_king" ],
          [ "Knight", "class_chess_game_1_1model_1_1pieces_1_1_knight.html", "class_chess_game_1_1model_1_1pieces_1_1_knight" ],
          [ "Pawn", "class_chess_game_1_1model_1_1pieces_1_1_pawn.html", "class_chess_game_1_1model_1_1pieces_1_1_pawn" ],
          [ "Piece", "class_chess_game_1_1model_1_1pieces_1_1_piece.html", "class_chess_game_1_1model_1_1pieces_1_1_piece" ],
          [ "Queen", "class_chess_game_1_1model_1_1pieces_1_1_queen.html", "class_chess_game_1_1model_1_1pieces_1_1_queen" ],
          [ "Rook", "class_chess_game_1_1model_1_1pieces_1_1_rook.html", "class_chess_game_1_1model_1_1pieces_1_1_rook" ],
          [ "SpecialPiece", "class_chess_game_1_1model_1_1pieces_1_1_special_piece.html", "class_chess_game_1_1model_1_1pieces_1_1_special_piece" ]
        ] ],
        [ "Board", "class_chess_game_1_1model_1_1_board.html", "class_chess_game_1_1model_1_1_board" ],
        [ "Coordinates", "class_chess_game_1_1model_1_1_coordinates.html", "class_chess_game_1_1model_1_1_coordinates" ],
        [ "Game", "class_chess_game_1_1model_1_1_game.html", "class_chess_game_1_1model_1_1_game" ],
        [ "Player", "class_chess_game_1_1model_1_1_player.html", "class_chess_game_1_1model_1_1_player" ]
      ] ],
      [ "Properties", "namespace_chess_game_1_1_properties.html", [
        [ "Resources", "class_chess_game_1_1_properties_1_1_resources.html", null ]
      ] ],
      [ "view", "namespace_chess_game_1_1view.html", [
        [ "FormGame", "class_chess_game_1_1view_1_1_form_game.html", "class_chess_game_1_1view_1_1_form_game" ],
        [ "FormMenu", "class_chess_game_1_1view_1_1_form_menu.html", "class_chess_game_1_1view_1_1_form_menu" ]
      ] ],
      [ "Chess", "class_chess_game_1_1_chess.html", "class_chess_game_1_1_chess" ]
    ] ]
];