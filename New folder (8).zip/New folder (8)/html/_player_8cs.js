var _player_8cs =
[
    [ "ChessGame.model.Player", "class_chess_game_1_1model_1_1_player.html", "class_chess_game_1_1model_1_1_player" ]
];