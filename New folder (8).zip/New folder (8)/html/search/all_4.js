var searchData=
[
  ['dispose_0',['Dispose',['../class_chess_game_1_1view_1_1_form_game.html#a5e665fe6ef8093c47cfe9095184a4c36',1,'ChessGame.view.FormGame.Dispose()'],['../class_chess_game_1_1view_1_1_form_menu.html#a4b73e96208d392fc84ccab97b94963b5',1,'ChessGame.view.FormMenu.Dispose()']]]
];
