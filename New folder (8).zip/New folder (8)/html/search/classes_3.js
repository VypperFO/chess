var searchData=
[
  ['game_0',['Game',['../class_chess_game_1_1model_1_1_game.html',1,'ChessGame::model']]]
];
