var searchData=
[
  ['chess_2eassemblyinfo_2ecs_0',['Chess.AssemblyInfo.cs',['../_chess_8_assembly_info_8cs.html',1,'']]],
  ['chess_2ecs_1',['Chess.cs',['../_chess_8cs.html',1,'']]],
  ['chess_2eglobalusings_2eg_2ecs_2',['Chess.GlobalUsings.g.cs',['../_chess_8_global_usings_8g_8cs.html',1,'']]],
  ['chessgame_2eassemblyinfo_2ecs_3',['ChessGame.AssemblyInfo.cs',['../_debug_2net6_80-windows_2_chess_game_8_assembly_info_8cs.html',1,'(Global Namespace)'],['../_release_2net6_80-windows_2_chess_game_8_assembly_info_8cs.html',1,'(Global Namespace)']]],
  ['chessgame_2eglobalusings_2eg_2ecs_4',['ChessGame.GlobalUsings.g.cs',['../_debug_2net6_80-windows_2_chess_game_8_global_usings_8g_8cs.html',1,'(Global Namespace)'],['../_release_2net6_80-windows_2_chess_game_8_global_usings_8g_8cs.html',1,'(Global Namespace)']]],
  ['coordinates_2ecs_5',['Coordinates.cs',['../_coordinates_8cs.html',1,'']]]
];
