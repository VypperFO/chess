var searchData=
[
  ['formgame_0',['FormGame',['../class_chess_game_1_1view_1_1_form_game.html',1,'ChessGame::view']]],
  ['formmenu_1',['FormMenu',['../class_chess_game_1_1view_1_1_form_menu.html',1,'ChessGame::view']]]
];
