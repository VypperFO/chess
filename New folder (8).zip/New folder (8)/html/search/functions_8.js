var searchData=
[
  ['newgame_0',['NewGame',['../class_chess_game_1_1_chess.html#a3b4782541bc66c263af10827ca7430dd',1,'ChessGame::Chess']]],
  ['newplayer_1',['NewPlayer',['../class_chess_game_1_1_chess.html#a98dfb04bc67adb1791ad09c59942c6fd',1,'ChessGame::Chess']]]
];
