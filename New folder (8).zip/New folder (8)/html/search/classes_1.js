var searchData=
[
  ['chess_0',['Chess',['../class_chess_game_1_1_chess.html',1,'ChessGame']]],
  ['coordinates_1',['Coordinates',['../class_chess_game_1_1model_1_1_coordinates.html',1,'ChessGame::model']]]
];
