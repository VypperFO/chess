var searchData=
[
  ['tostring_0',['ToString',['../class_chess_game_1_1model_1_1_board.html#af62e8d3deece4ff8be82e8d6119548d2',1,'ChessGame::model::Board']]],
  ['type_1',['Type',['../class_chess_game_1_1model_1_1pieces_1_1_piece.html#af0d708a2624c20f119f8ebea0cefb57d',1,'ChessGame::model::pieces::Piece']]]
];
