var searchData=
[
  ['addplayertogame_0',['AddPlayerToGame',['../class_chess_game_1_1model_1_1_game.html#ac4bbf7763434925d548254da58134d51',1,'ChessGame::model::Game']]]
];
