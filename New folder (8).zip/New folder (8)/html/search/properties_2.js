var searchData=
[
  ['id_0',['Id',['../class_chess_game_1_1view_1_1_form_game.html#a51b889833389ec7d357d65e20ee13ace',1,'ChessGame::view::FormGame']]],
  ['ismoved_1',['IsMoved',['../class_chess_game_1_1model_1_1pieces_1_1_special_piece.html#a500f3449a55088b062c4440e08392392',1,'ChessGame::model::pieces::SpecialPiece']]]
];
