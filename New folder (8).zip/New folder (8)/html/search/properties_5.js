var searchData=
[
  ['pieces_0',['Pieces',['../class_chess_game_1_1model_1_1pieces_1_1_piece.html#a0f87ca6eb9d4729e7d02def7a8f455f6',1,'ChessGame::model::pieces::Piece']]]
];
