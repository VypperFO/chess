var searchData=
[
  ['resourcemanager_0',['ResourceManager',['../class_chess_game_1_1_properties_1_1_resources.html#a806a427092a4893c311eadc566248faf',1,'ChessGame::Properties::Resources']]]
];
