var searchData=
[
  ['xdestination_0',['XDestination',['../class_chess_game_1_1model_1_1_coordinates.html#a48b738ab28095f5e785794993afa9d51',1,'ChessGame::model::Coordinates']]],
  ['xstart_1',['XStart',['../class_chess_game_1_1model_1_1_coordinates.html#a8ae07f2d4de4c3cf24d2722b9d872d71',1,'ChessGame::model::Coordinates']]]
];
