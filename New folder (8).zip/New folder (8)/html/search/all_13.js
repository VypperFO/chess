var searchData=
[
  ['ydestination_0',['YDestination',['../class_chess_game_1_1model_1_1_coordinates.html#a010831e191d3e0d502fd59c9dc109ee6',1,'ChessGame::model::Coordinates']]],
  ['ystart_1',['YStart',['../class_chess_game_1_1model_1_1_coordinates.html#a5cdf05564fc3a0b87fcba47e9852e1b5',1,'ChessGame::model::Coordinates']]]
];
