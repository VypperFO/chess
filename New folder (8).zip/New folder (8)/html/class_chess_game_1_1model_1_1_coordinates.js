var class_chess_game_1_1model_1_1_coordinates =
[
    [ "Coordinates", "class_chess_game_1_1model_1_1_coordinates.html#a550b74a941b36a015ee251e792d3c1da", null ],
    [ "Coordinates", "class_chess_game_1_1model_1_1_coordinates.html#a880afdb89219f930e1adcfb842a77bff", null ],
    [ "XDestination", "class_chess_game_1_1model_1_1_coordinates.html#a48b738ab28095f5e785794993afa9d51", null ],
    [ "XStart", "class_chess_game_1_1model_1_1_coordinates.html#a8ae07f2d4de4c3cf24d2722b9d872d71", null ],
    [ "YDestination", "class_chess_game_1_1model_1_1_coordinates.html#a010831e191d3e0d502fd59c9dc109ee6", null ],
    [ "YStart", "class_chess_game_1_1model_1_1_coordinates.html#a5cdf05564fc3a0b87fcba47e9852e1b5", null ]
];