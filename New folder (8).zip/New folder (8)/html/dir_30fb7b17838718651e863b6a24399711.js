var dir_30fb7b17838718651e863b6a24399711 =
[
    [ ".NETCoreApp,Version=v6.0.AssemblyAttributes.cs", "_debug_2net6_80-windows_2_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html", null ],
    [ "Chess.AssemblyInfo.cs", "_chess_8_assembly_info_8cs.html", null ],
    [ "Chess.GlobalUsings.g.cs", "_chess_8_global_usings_8g_8cs.html", null ],
    [ "ChessGame.AssemblyInfo.cs", "_debug_2net6_80-windows_2_chess_game_8_assembly_info_8cs.html", null ],
    [ "ChessGame.GlobalUsings.g.cs", "_debug_2net6_80-windows_2_chess_game_8_global_usings_8g_8cs.html", null ],
    [ "Echec.AssemblyInfo.cs", "_echec_8_assembly_info_8cs.html", null ],
    [ "Echec.GlobalUsings.g.cs", "_echec_8_global_usings_8g_8cs.html", null ]
];