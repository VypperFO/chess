var _coordinates_8cs =
[
    [ "ChessGame.model.Coordinates", "class_chess_game_1_1model_1_1_coordinates.html", "class_chess_game_1_1model_1_1_coordinates" ]
];