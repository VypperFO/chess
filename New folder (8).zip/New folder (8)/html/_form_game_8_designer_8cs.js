var _form_game_8_designer_8cs =
[
    [ "ChessGame.view.FormGame", "class_chess_game_1_1view_1_1_form_game.html", "class_chess_game_1_1view_1_1_form_game" ]
];