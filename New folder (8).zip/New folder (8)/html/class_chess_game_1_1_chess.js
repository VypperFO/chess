var class_chess_game_1_1_chess =
[
    [ "Chess", "class_chess_game_1_1_chess.html#adbe13665abc531e8fd1daff6bed14a39", null ],
    [ "GetPlayer", "class_chess_game_1_1_chess.html#ace5d5fda144a594e9d76afa94128f372", null ],
    [ "GetStats", "class_chess_game_1_1_chess.html#ae516ee9dec17a134646495be1bd00b40", null ],
    [ "IsUserExisting", "class_chess_game_1_1_chess.html#a9c0cbfa42989fff68e2b7eac7de255b2", null ],
    [ "NewGame", "class_chess_game_1_1_chess.html#a3b4782541bc66c263af10827ca7430dd", null ],
    [ "NewPlayer", "class_chess_game_1_1_chess.html#a98dfb04bc67adb1791ad09c59942c6fd", null ],
    [ "PlayMove", "class_chess_game_1_1_chess.html#a63e3a502006136c64a0a629a4cc0a9f0", null ],
    [ "ReadStats", "class_chess_game_1_1_chess.html#ae2c7d20d030c87bc3ce778b558733af8", null ],
    [ "SendPlayers", "class_chess_game_1_1_chess.html#aec72b9f32fe721c9bb9915d6fab0ee75", null ],
    [ "SetGameNull", "class_chess_game_1_1_chess.html#a93bff06c3cac5043bcb9251d5e809439", null ],
    [ "SetLose", "class_chess_game_1_1_chess.html#ad78b77372136bc82abfbad4b5f4e1c69", null ],
    [ "SetNull", "class_chess_game_1_1_chess.html#a623b0210b7470d07a4349df8b14bd857", null ],
    [ "SetWin", "class_chess_game_1_1_chess.html#a5bfb7c6b6904597d35272a791522d4f7", null ]
];