var namespace_chess_game_1_1model =
[
    [ "pieces", "namespace_chess_game_1_1model_1_1pieces.html", "namespace_chess_game_1_1model_1_1pieces" ],
    [ "Board", "class_chess_game_1_1model_1_1_board.html", "class_chess_game_1_1model_1_1_board" ],
    [ "Coordinates", "class_chess_game_1_1model_1_1_coordinates.html", "class_chess_game_1_1model_1_1_coordinates" ],
    [ "Game", "class_chess_game_1_1model_1_1_game.html", "class_chess_game_1_1model_1_1_game" ],
    [ "Player", "class_chess_game_1_1model_1_1_player.html", "class_chess_game_1_1model_1_1_player" ]
];