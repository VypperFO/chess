var dir_0707acc1238df4c6c2268f5b96e1c857 =
[
    [ "Bishop.cs", "_bishop_8cs.html", "_bishop_8cs" ],
    [ "King.cs", "_king_8cs.html", "_king_8cs" ],
    [ "Knight.cs", "_knight_8cs.html", "_knight_8cs" ],
    [ "Pawn.cs", "_pawn_8cs.html", "_pawn_8cs" ],
    [ "Piece.cs", "_piece_8cs.html", "_piece_8cs" ],
    [ "Queen.cs", "_queen_8cs.html", "_queen_8cs" ],
    [ "Rook.cs", "_rook_8cs.html", "_rook_8cs" ],
    [ "SpecialPiece.cs", "_special_piece_8cs.html", "_special_piece_8cs" ]
];