var dir_8f2d7e2c72b03a29d397ea6810b3398a =
[
    [ "net6.0-windows", "dir_606d18312f2eb321886fdcbe6d519c6e.html", "dir_606d18312f2eb321886fdcbe6d519c6e" ]
];