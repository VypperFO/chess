var dir_81fc332b0272ab851f6b5a12f0c0ae0d =
[
    [ "model", "dir_4c35fb7f3abf581bd7f272b4592ef4fc.html", "dir_4c35fb7f3abf581bd7f272b4592ef4fc" ],
    [ "obj", "dir_fbf8d27c73945cde78b8f80efb56de88.html", "dir_fbf8d27c73945cde78b8f80efb56de88" ],
    [ "Properties", "dir_eaa9ebbc97b059cead7ec12b672513e9.html", "dir_eaa9ebbc97b059cead7ec12b672513e9" ],
    [ "view", "dir_14da744e7bb74993b94d5b5757c3f899.html", "dir_14da744e7bb74993b94d5b5757c3f899" ],
    [ "Chess.cs", "_chess_8cs.html", "_chess_8cs" ]
];