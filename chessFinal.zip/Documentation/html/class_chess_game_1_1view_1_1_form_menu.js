var class_chess_game_1_1view_1_1_form_menu =
[
    [ "FormMenu", "class_chess_game_1_1view_1_1_form_menu.html#a2d21bf52cb438cf8f89a6b4f107c7091", null ],
    [ "Dispose", "class_chess_game_1_1view_1_1_form_menu.html#a4b73e96208d392fc84ccab97b94963b5", null ]
];