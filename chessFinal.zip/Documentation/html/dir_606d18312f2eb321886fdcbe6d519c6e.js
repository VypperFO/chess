var dir_606d18312f2eb321886fdcbe6d519c6e =
[
    [ ".NETCoreApp,Version=v6.0.AssemblyAttributes.cs", "_release_2net6_80-windows_2_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html", null ],
    [ "ChessGame.AssemblyInfo.cs", "_release_2net6_80-windows_2_chess_game_8_assembly_info_8cs.html", null ],
    [ "ChessGame.GlobalUsings.g.cs", "_release_2net6_80-windows_2_chess_game_8_global_usings_8g_8cs.html", null ]
];