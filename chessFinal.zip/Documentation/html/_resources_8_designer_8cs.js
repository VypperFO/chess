var _resources_8_designer_8cs =
[
    [ "ChessGame.Properties.Resources", "class_chess_game_1_1_properties_1_1_resources.html", null ]
];