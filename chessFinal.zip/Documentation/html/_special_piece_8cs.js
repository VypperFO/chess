var _special_piece_8cs =
[
    [ "ChessGame.model.pieces.SpecialPiece", "class_chess_game_1_1model_1_1pieces_1_1_special_piece.html", "class_chess_game_1_1model_1_1pieces_1_1_special_piece" ]
];