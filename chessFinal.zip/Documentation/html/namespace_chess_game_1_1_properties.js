var namespace_chess_game_1_1_properties =
[
    [ "Resources", "class_chess_game_1_1_properties_1_1_resources.html", null ]
];