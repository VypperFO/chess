var _queen_8cs =
[
    [ "ChessGame.model.pieces.Queen", "class_chess_game_1_1model_1_1pieces_1_1_queen.html", "class_chess_game_1_1model_1_1pieces_1_1_queen" ]
];