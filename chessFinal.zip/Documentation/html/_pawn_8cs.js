var _pawn_8cs =
[
    [ "ChessGame.model.pieces.Pawn", "class_chess_game_1_1model_1_1pieces_1_1_pawn.html", "class_chess_game_1_1model_1_1pieces_1_1_pawn" ]
];