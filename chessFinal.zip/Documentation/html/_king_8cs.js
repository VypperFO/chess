var _king_8cs =
[
    [ "ChessGame.model.pieces.King", "class_chess_game_1_1model_1_1pieces_1_1_king.html", "class_chess_game_1_1model_1_1pieces_1_1_king" ]
];