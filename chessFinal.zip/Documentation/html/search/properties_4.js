var searchData=
[
  ['name_0',['Name',['../class_chess_game_1_1model_1_1_player.html#af61f864c782b49d6a078345db47a9ff4',1,'ChessGame::model::Player']]],
  ['nbdefeat_1',['NbDefeat',['../class_chess_game_1_1model_1_1_player.html#a49c9b9eabb6998d64686bdab2c2a17e7',1,'ChessGame::model::Player']]],
  ['nbnull_2',['NbNull',['../class_chess_game_1_1model_1_1_player.html#a47c224a5e200de23c08e85a03c367734',1,'ChessGame::model::Player']]],
  ['nbvictory_3',['NbVictory',['../class_chess_game_1_1model_1_1_player.html#afed1b479d95e4015b252cfd8c43a1458',1,'ChessGame::model::Player']]]
];
