var searchData=
[
  ['readstats_0',['ReadStats',['../class_chess_game_1_1_chess.html#ae2c7d20d030c87bc3ce778b558733af8',1,'ChessGame::Chess']]],
  ['rook_1',['Rook',['../class_chess_game_1_1model_1_1pieces_1_1_rook.html#a2ec757c9bb469470688e97b8fccdb760',1,'ChessGame.model.pieces.Rook.Rook()'],['../class_chess_game_1_1model_1_1pieces_1_1_rook.html#a70782710fa30810cc5230a358b8e8db4',1,'ChessGame.model.pieces.Rook.Rook(char type, Piece[] pieces, bool isMoved=false)']]]
];
