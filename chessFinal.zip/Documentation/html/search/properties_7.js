var searchData=
[
  ['type_0',['Type',['../class_chess_game_1_1model_1_1pieces_1_1_piece.html#af0d708a2624c20f119f8ebea0cefb57d',1,'ChessGame::model::pieces::Piece']]]
];
