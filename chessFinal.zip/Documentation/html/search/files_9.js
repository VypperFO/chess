var searchData=
[
  ['resources_2edesigner_2ecs_0',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]],
  ['rook_2ecs_1',['Rook.cs',['../_rook_8cs.html',1,'']]]
];
