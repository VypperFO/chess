var searchData=
[
  ['samecolor_0',['SameColor',['../class_chess_game_1_1model_1_1pieces_1_1_piece.html#ad3b8d1a3ac153f9cd3c53b113e9eeaa5',1,'ChessGame::model::pieces::Piece']]],
  ['samecolortemp_1',['SameColorTemp',['../class_chess_game_1_1model_1_1pieces_1_1_piece.html#af7b0c6871964a7875d05714b45980f2e',1,'ChessGame::model::pieces::Piece']]],
  ['sendplayers_2',['SendPlayers',['../class_chess_game_1_1_chess.html#aec72b9f32fe721c9bb9915d6fab0ee75',1,'ChessGame::Chess']]],
  ['setgamenull_3',['SetGameNull',['../class_chess_game_1_1_chess.html#a93bff06c3cac5043bcb9251d5e809439',1,'ChessGame::Chess']]],
  ['setlose_4',['SetLose',['../class_chess_game_1_1_chess.html#ad78b77372136bc82abfbad4b5f4e1c69',1,'ChessGame::Chess']]],
  ['setnull_5',['SetNull',['../class_chess_game_1_1_chess.html#a623b0210b7470d07a4349df8b14bd857',1,'ChessGame::Chess']]],
  ['setwin_6',['SetWin',['../class_chess_game_1_1_chess.html#a5bfb7c6b6904597d35272a791522d4f7',1,'ChessGame::Chess']]],
  ['specialpiece_7',['SpecialPiece',['../class_chess_game_1_1model_1_1pieces_1_1_special_piece.html#ae1edb95a51892558e4a8c1cd6bcc5397',1,'ChessGame.model.pieces.SpecialPiece.SpecialPiece()'],['../class_chess_game_1_1model_1_1pieces_1_1_special_piece.html#aa52eb7a506e4639b94a6d109763e4baf',1,'ChessGame.model.pieces.SpecialPiece.SpecialPiece(char type, Piece[] pieces, bool isMoved=false)']]]
];
