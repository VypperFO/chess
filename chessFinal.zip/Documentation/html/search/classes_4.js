var searchData=
[
  ['king_0',['King',['../class_chess_game_1_1model_1_1pieces_1_1_king.html',1,'ChessGame::model::pieces']]],
  ['knight_1',['Knight',['../class_chess_game_1_1model_1_1pieces_1_1_knight.html',1,'ChessGame::model::pieces']]]
];
