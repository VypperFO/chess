var searchData=
[
  ['pawn_0',['Pawn',['../class_chess_game_1_1model_1_1pieces_1_1_pawn.html',1,'ChessGame::model::pieces']]],
  ['piece_1',['Piece',['../class_chess_game_1_1model_1_1pieces_1_1_piece.html',1,'ChessGame::model::pieces']]],
  ['player_2',['Player',['../class_chess_game_1_1model_1_1_player.html',1,'ChessGame::model']]]
];
