var searchData=
[
  ['resources_0',['Resources',['../class_chess_game_1_1_properties_1_1_resources.html',1,'ChessGame::Properties']]],
  ['rook_1',['Rook',['../class_chess_game_1_1model_1_1pieces_1_1_rook.html',1,'ChessGame::model::pieces']]]
];
