var searchData=
[
  ['chessgame_0',['ChessGame',['../namespace_chess_game.html',1,'']]],
  ['model_1',['model',['../namespace_chess_game_1_1model.html',1,'ChessGame']]],
  ['pieces_2',['pieces',['../namespace_chess_game_1_1model_1_1pieces.html',1,'ChessGame::model']]],
  ['properties_3',['Properties',['../namespace_chess_game_1_1_properties.html',1,'ChessGame']]],
  ['view_4',['view',['../namespace_chess_game_1_1view.html',1,'ChessGame']]]
];
