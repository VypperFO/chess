var searchData=
[
  ['bishop_0',['Bishop',['../class_chess_game_1_1model_1_1pieces_1_1_bishop.html#ab87e9e025100cd395abfafc52cddb153',1,'ChessGame.model.pieces.Bishop.Bishop()'],['../class_chess_game_1_1model_1_1pieces_1_1_bishop.html#aa9415d04689ce3aa2c7ec1a28cb64b0a',1,'ChessGame.model.pieces.Bishop.Bishop(char type, Piece[] pieces)']]],
  ['board_1',['Board',['../class_chess_game_1_1model_1_1_board.html#ab5ae11f417f9b240153b94d5a771833f',1,'ChessGame::model::Board']]]
];
