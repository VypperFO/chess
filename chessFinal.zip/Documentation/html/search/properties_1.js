var searchData=
[
  ['chessboard_0',['chessboard',['../class_chess_game_1_1_properties_1_1_resources.html#acb8eeee8fe19eb6d31e7293c911a039d',1,'ChessGame::Properties::Resources']]],
  ['culture_1',['Culture',['../class_chess_game_1_1_properties_1_1_resources.html#a5f51c8613c18a82f391c01de0fa132a3',1,'ChessGame::Properties::Resources']]]
];
