var searchData=
[
  ['checkboardconfig_0',['CheckBoardConfig',['../class_chess_game_1_1model_1_1_game.html#a9ef65101d2842e6c5d9345cec075bf01',1,'ChessGame::model::Game']]],
  ['chess_1',['Chess',['../class_chess_game_1_1_chess.html#adbe13665abc531e8fd1daff6bed14a39',1,'ChessGame.Chess.Chess()'],['../class_chess_game_1_1_chess.html',1,'ChessGame.Chess']]],
  ['chess_2eassemblyinfo_2ecs_2',['Chess.AssemblyInfo.cs',['../_chess_8_assembly_info_8cs.html',1,'']]],
  ['chess_2ecs_3',['Chess.cs',['../_chess_8cs.html',1,'']]],
  ['chess_2eglobalusings_2eg_2ecs_4',['Chess.GlobalUsings.g.cs',['../_chess_8_global_usings_8g_8cs.html',1,'']]],
  ['chessboard_5',['chessboard',['../class_chess_game_1_1_properties_1_1_resources.html#acb8eeee8fe19eb6d31e7293c911a039d',1,'ChessGame::Properties::Resources']]],
  ['chessgame_6',['ChessGame',['../namespace_chess_game.html',1,'']]],
  ['chessgame_2eassemblyinfo_2ecs_7',['ChessGame.AssemblyInfo.cs',['../_debug_2net6_80-windows_2_chess_game_8_assembly_info_8cs.html',1,'(Global Namespace)'],['../_release_2net6_80-windows_2_chess_game_8_assembly_info_8cs.html',1,'(Global Namespace)']]],
  ['chessgame_2eglobalusings_2eg_2ecs_8',['ChessGame.GlobalUsings.g.cs',['../_debug_2net6_80-windows_2_chess_game_8_global_usings_8g_8cs.html',1,'(Global Namespace)'],['../_release_2net6_80-windows_2_chess_game_8_global_usings_8g_8cs.html',1,'(Global Namespace)']]],
  ['coordinates_9',['Coordinates',['../class_chess_game_1_1model_1_1_coordinates.html',1,'ChessGame.model.Coordinates'],['../class_chess_game_1_1model_1_1_coordinates.html#a550b74a941b36a015ee251e792d3c1da',1,'ChessGame.model.Coordinates.Coordinates()'],['../class_chess_game_1_1model_1_1_coordinates.html#a880afdb89219f930e1adcfb842a77bff',1,'ChessGame.model.Coordinates.Coordinates(int xStart, int yStart, int xDestination, int yDestination)']]],
  ['coordinates_2ecs_10',['Coordinates.cs',['../_coordinates_8cs.html',1,'']]],
  ['culture_11',['Culture',['../class_chess_game_1_1_properties_1_1_resources.html#a5f51c8613c18a82f391c01de0fa132a3',1,'ChessGame::Properties::Resources']]],
  ['model_12',['model',['../namespace_chess_game_1_1model.html',1,'ChessGame']]],
  ['pieces_13',['pieces',['../namespace_chess_game_1_1model_1_1pieces.html',1,'ChessGame::model']]],
  ['properties_14',['Properties',['../namespace_chess_game_1_1_properties.html',1,'ChessGame']]],
  ['view_15',['view',['../namespace_chess_game_1_1view.html',1,'ChessGame']]]
];
