var _form_menu_8_designer_8cs =
[
    [ "ChessGame.view.FormMenu", "class_chess_game_1_1view_1_1_form_menu.html", "class_chess_game_1_1view_1_1_form_menu" ]
];