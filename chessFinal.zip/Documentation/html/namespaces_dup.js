var namespaces_dup =
[
    [ "ChessGame", "namespace_chess_game.html", "namespace_chess_game" ]
];