var _piece_8cs =
[
    [ "ChessGame.model.pieces.Piece", "class_chess_game_1_1model_1_1pieces_1_1_piece.html", "class_chess_game_1_1model_1_1pieces_1_1_piece" ]
];