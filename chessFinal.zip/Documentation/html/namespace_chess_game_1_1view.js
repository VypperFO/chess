var namespace_chess_game_1_1view =
[
    [ "FormGame", "class_chess_game_1_1view_1_1_form_game.html", "class_chess_game_1_1view_1_1_form_game" ],
    [ "FormMenu", "class_chess_game_1_1view_1_1_form_menu.html", "class_chess_game_1_1view_1_1_form_menu" ]
];